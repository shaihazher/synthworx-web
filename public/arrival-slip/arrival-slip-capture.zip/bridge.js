if (location.pathname === "/arrival-slip/desk") {
  document.addEventListener("arrival-slip-arm", (e) => {
    const ref = e.detail;
    if (ref === "" || /^AS-[A-F0-9]{10}$/.test(ref))
      void chrome.runtime.sendMessage({ type: "arm", ref }).catch(() => {});
  });
  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (sender.id !== chrome.runtime.id || m.type !== "evidence") return;
    let accepted = false;
    const confirm = (e) => {
      accepted = e.detail === m.reference;
    };
    document.addEventListener("arrival-slip-accepted", confirm);
    document.dispatchEvent(
      new CustomEvent("arrival-slip-evidence", { detail: m }),
    );
    document.removeEventListener("arrival-slip-accepted", confirm);
    reply({ ok: accepted });
  });
  document.dispatchEvent(new CustomEvent("arrival-slip-ready"));
}
