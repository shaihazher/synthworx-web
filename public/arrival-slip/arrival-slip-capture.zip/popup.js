"use strict";
(() => {
  // src/extension/context/crop-rectangle.js
  function cropRectangle(start2, end, imageBounds) {
    return {
      x: Math.min(start2.x, end.x) - imageBounds.left,
      y: Math.min(start2.y, end.y) - imageBounds.top,
      width: Math.abs(start2.x - end.x),
      height: Math.abs(start2.y - end.y)
    };
  }

  // arrival-slip/extension/popup.js
  var $ = (id) => document.getElementById(id);
  var desk;
  var tab;
  var selected;
  var image;
  function selection() {
    const range = getSelection();
    if (!range || !range.rangeCount || range.isCollapsed || ["INPUT", "TEXTAREA"].includes(document.activeElement?.tagName))
      return null;
    const text = range.toString().trim().slice(0, 1e3);
    if (!text) return null;
    const r = range.getRangeAt(0).getBoundingClientRect();
    return {
      text,
      host: location.hostname,
      width: innerWidth,
      height: innerHeight,
      bounds: {
        left: Math.max(0, r.left - 3),
        top: Math.max(0, r.top - 3),
        right: Math.min(innerWidth, r.right + 3),
        bottom: Math.min(innerHeight, r.bottom + 3)
      }
    };
  }
  async function makeImage() {
    const [before] = await chrome.tabs.query({
      active: true,
      windowId: tab.windowId
    });
    if (before?.id !== tab.id) throw Error("The tab changed. Reopen the helper.");
    const raw = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: "png"
    });
    const [after] = await chrome.tabs.query({
      active: true,
      windowId: tab.windowId
    });
    const latest = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: selection
    }))[0]?.result;
    if (after?.id !== tab.id || !latest || latest.text !== selected.text || JSON.stringify(latest.bounds) !== JSON.stringify(selected.bounds))
      throw Error("The selection moved. Highlight it again.");
    const bitmap = await createImageBitmap(await (await fetch(raw)).blob());
    try {
      const { left, top, right, bottom } = selected.bounds;
      if (right <= left || bottom <= top)
        throw Error("Scroll the selection into view.");
      const r = cropRectangle(
        { x: left, y: top },
        { x: right, y: bottom },
        { left: 0, top: 0 }
      );
      const sx = bitmap.width / selected.width, sy = bitmap.height / selected.height;
      const factor = Math.min(sx, 1e3 / r.width, 420 / r.height);
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(r.width * factor));
      c.height = Math.max(1, Math.round(r.height * factor));
      c.getContext("2d").drawImage(
        bitmap,
        r.x * sx,
        r.y * sy,
        r.width * sx,
        r.height * sy,
        0,
        0,
        c.width,
        c.height
      );
      const jpeg = c.toDataURL("image/jpeg", 0.68);
      if (jpeg.length >= 36e4) throw Error("Choose a smaller area.");
      return jpeg;
    } finally {
      bitmap.close();
    }
  }
  async function start() {
    ({ desk } = await chrome.storage.session.get("desk"));
    if (!desk)
      throw Error("Start a check in the receipt book and leave that tab open.");
    $("ref").textContent = desk.ref;
    [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:\/\//.test(tab.url || ""))
      throw Error("Use the helper on the web page or inbox you are checking.");
    selected = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: selection
    }))[0]?.result;
    if (!selected)
      throw Error(
        "Highlight the visible confirmation or test entry, then open the helper again."
      );
    $("quote").textContent = selected.text;
    $("summary").textContent = "From " + selected.host + ". Choose where to attach this excerpt.";
    $("choices").hidden = false;
  }
  $("image").onchange = async () => {
    if (!$("image").checked) {
      image = void 0;
      $("preview").hidden = true;
      return;
    }
    $("page").disabled = $("delivery").disabled = true;
    try {
      image = await makeImage();
      $("preview").src = image;
      $("preview").hidden = false;
    } catch (e) {
      $("summary").textContent = e.message;
      $("image").checked = false;
      image = void 0;
      $("preview").hidden = true;
    } finally {
      $("page").disabled = $("delivery").disabled = false;
    }
  };
  for (const side of ["page", "delivery"])
    $(side).onclick = async () => {
      try {
        const response = await chrome.runtime.sendMessage({
          type: "clip",
          reference: desk.ref,
          side,
          text: selected.text,
          host: selected.host,
          image
        });
        if (!response?.ok)
          throw Error(
            "Reopen the unfinished slip in the receipt book and try again."
          );
        $("choices").hidden = true;
        $("summary").textContent = "Attached to " + desk.ref + ". Return to the book to review the result.";
      } catch (e) {
        $("summary").textContent = e.message;
      }
    };
  start().catch((e) => {
    $("summary").textContent = e.message;
  });
})();
