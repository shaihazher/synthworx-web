chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (sender.id !== chrome.runtime.id) return;
  (async () => {
    if (
      m.type === "arm" &&
      sender.tab?.id &&
      sender.url &&
      new URL(sender.url).origin === "https://synthworx.com" &&
      new URL(sender.url).pathname === "/arrival-slip/desk"
    ) {
      if (m.ref)
        await chrome.storage.session.set({
          desk: { tab: sender.tab.id, ref: m.ref },
        });
      else {
        const { desk } = await chrome.storage.session.get("desk");
        if (desk?.tab === sender.tab.id)
          await chrome.storage.session.remove("desk");
      }
      return { ok: true };
    }
    if (
      m.type === "clip" &&
      sender.url === chrome.runtime.getURL("popup.html")
    ) {
      const { desk } = await chrome.storage.session.get("desk");
      if (!desk || desk.ref !== m.reference) return { ok: false };
      return await chrome.tabs.sendMessage(desk.tab, {
        ...m,
        type: "evidence",
      });
    }
    return { ok: false };
  })()
    .then(reply)
    .catch(() => reply({ ok: false }));
  return true;
});
